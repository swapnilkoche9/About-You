export interface FilterOptions {
  name?: any; // name should not be a boolean value, sometimes it is coming as string sometimes as boolean // it should always be string from backend
  productCount: number;
  id?: string | number;
}

export interface Filter {
  id?: number | string;
  slug: string;
  name?: string;
  type?: string;
  values?: FilterOptions[];
}
