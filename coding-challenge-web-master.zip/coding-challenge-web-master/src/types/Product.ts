import {
  AttributeGroupMulti,
  AttributeGroupSingle,
} from '@aboutyou/backbone/types/BapiProduct';

export interface Product {
  id: number;
  image: string | null;
  name: string;
  price?: string;
  colorDetail: AttributeGroupMulti|AttributeGroupSingle;
}
