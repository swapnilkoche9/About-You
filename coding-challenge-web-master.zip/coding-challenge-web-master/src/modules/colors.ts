export const colors = {
  blau: 'blue',
  schwarz: 'black',
  grau: 'gray',
  weiß: 'white',
  grün: 'green',
  rot: 'red',
  braun: 'brown',
  beige: '#f5f5dc',
  mischfarben:
    'linear-gradient(45deg, rgb(255, 152, 0), rgb(255, 152, 0) 100%) 0px 0px / 50% 50% no-repeat, linear-gradient(135deg, rgb(76, 175, 80), rgb(76, 175, 80)100%) 0px 0px/50%  no-repeat,   linear-gradient(225deg, rgb(244, 67, 54), rgb(244, 67, 54)100%) 10px 10px   no-repeat,  linear-gradient(2255deg, rgb(33, 150, 243), rgb(33, 150, 243)100%) 0px 0px no-repeat;',
  gelb: 'yellow',
  orange: 'orange',
  pink: 'pink',
  lila: 'purple',
  silber: '#C0C0C0',
  gold: '#D4AF37',
  bronze: '#cd7f32',
};
