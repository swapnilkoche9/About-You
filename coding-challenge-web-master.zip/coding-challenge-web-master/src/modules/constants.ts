export const constants = {
  filter_button_label: 'Filter',
  clear_all__button_label: 'Zurücksetzen',
  submit_button_label: 'Submit',
  show_more_materials_button_label: 'Mehr Material anzeigen',
  show_less_materials_button_label: 'Weniger Material anzeigen',
};
