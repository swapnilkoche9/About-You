import React from 'react';
import styled from 'styled-components';

type ButtonProps = {
  onClick?: (ev: React.MouseEvent<HTMLButtonElement>) => void;
  children?: React.ReactNode;
};

const Button: React.FC<ButtonProps> = ({ children, onClick }) => {
  return (
    <ButtonWrapper onClick={onClick}>
      <span>{children}</span>
    </ButtonWrapper>
  );
};

Button.defaultProps = {
  onClick: () => {},
};

const ButtonWrapper = styled.button`
   {
    display: inline-block;
    background: #ffffff;
    border-radius: 6px;
    box-sizing: border-box;
    border: 1px solid #232323;
    height: 48px;
    min-width: 100px;
    color: #232323;
    padding: 0 12px;
    margin: 0;
    outline:none
    transition-duration: 0.25s;
    cursor: pointer;
    font-size: 14px;
    line-height: 1.28571;
    color: rgb(155, 155, 155);

    &:hover,
    &:focus,
    &:active {
      background: #ffffff;
    }
    
    > span{
     display: flex;
     align-items: center;
     justify-content: center;
     width: 100%;
  }
`;

export default Button;
