import React, { FC } from 'react';
import styled, { keyframes } from 'styled-components';
import Filter from './Filter';
import Button from './Button';
import { constants } from '../modules/constants';
import { Filter as Filters } from '../types/Filter';

interface FilterPanelProps {
  filters: Filters[];
  handleCheckboxChange?: (ev: React.ChangeEvent<HTMLInputElement>) => void;
  handleSubmit?: (ev: React.MouseEvent<HTMLButtonElement>) => void;
  clearAllFilterOptions?: (filterName: string) => void;
}

const FilterPanel: FC<FilterPanelProps> = ({
  filters,
  handleCheckboxChange,
  handleSubmit,
  clearAllFilterOptions,
}) => {
  return (
    <FiltersWrapper>
      {filters.map(
        filter =>
          filter && (
            <Panel key={filter.name}>
              <Filter
                filter={filter}
                onChange={handleCheckboxChange}
                clearAllFilterOptions={clearAllFilterOptions}
              />
            </Panel>
          ),
      )}
      <SubmitButton>
        <Button onClick={handleSubmit}>{constants.submit_button_label}</Button>
      </SubmitButton>
    </FiltersWrapper>
  );
};

const slideFromRight = keyframes`
  0% {
    transform: translate(100%);
}
  100% {
    transform: translateX(0);
}
`;

const FiltersWrapper = styled.header`
  background:rgba(51, 65, 70, 0.5);
  position:absolute;
  top:0;
  right:0
  display: flex;
  border-radius: 4px;
  width: 350px;
  max-height: 100%;
  flex-direction: column;
  overflow: scroll;
  border-collapse: separate;
  box-shadow: 0px 2px 8px rgba(0, 0, 0, 0.12);
  animation: 0.3s ease-out 0s 1 ${slideFromRight};
`;

const Panel = styled.div`
  margin-bottom: 10px;
`;

const SubmitButton = styled.div`
  > button {
    width: 100%;
    background: black;
    color: white;

    &:hover {
      background: white;
      color: black;
    }
  }
  display: flex;
  justify-content: center;
`;

export default FilterPanel;
