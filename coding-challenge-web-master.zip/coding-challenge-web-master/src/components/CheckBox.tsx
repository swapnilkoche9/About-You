import React from 'react';
import styled from 'styled-components';
import { colors } from '../modules/colors';

interface CheckboxProps {
  id: string;
  value?: string;
  name: string;
  checked?: boolean;
  label?: string;
  onChange?: (ev: React.ChangeEvent<HTMLInputElement>) => void;
}

const Checkbox: React.FC<CheckboxProps> = ({
  id,
  value,
  name,
  checked,
  label,
  onChange,
}) => {
  return (
    <CheckBox key={label} color={colors[label] ? colors[label] : ''}>
      <label htmlFor={id}>
        <input
          id={id}
          value={value}
          name={name}
          type="checkbox"
          checked={checked}
          onChange={onChange}
        />
        <span />
      </label>
      <CheckBoxLabel>{label}</CheckBoxLabel>
    </CheckBox>
  );
};

const CheckBox = styled.div`
  display: flex;
  align-items: center;

  > label > input {
    display: none;

    + span {
      display: flex;
      width: 20px;
      height: 20px;
      background: ${props => props.color};
      align-items: center;
      justify-content: center;
      color: #ffffff;
      margin: 5px;
      border: 2px solid
        ${props =>
          props.color === 'white' || props.color === '' ? 'gray' : props.color};
      border-radius: 4px;
      box-sizing: border-box;
      transition: all 150ms;
    }

    &:checked {
      + span {
        &::before {
          content: '✔';
          font-family: 'Material Icons';
          font-size: 14px;
          color: ${props =>
            props.color === 'white' || props.color === '' ? 'black' : 'white'};
        }
      }
    }
  }
`;

const CheckBoxLabel = styled.label`
  margin-left: 10px;
  font-size: 14px;
  line-height: 1.28571;
  color: rgb(155, 155, 155);
`;

export default Checkbox;
