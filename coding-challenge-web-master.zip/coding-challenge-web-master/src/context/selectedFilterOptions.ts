import { createContext } from 'react';

export const SelectedFilterOptionsContext = createContext(null);
